A Pen created at CodePen.io. You can find this one at http://codepen.io/tnakatani/pen/nwebL.

 Item interface with functionality to add & remove items.

Dynamically recalculate total price with Collection view.

Still need to add editing capabilities, multiple items, and a better way to render total price.