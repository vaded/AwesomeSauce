A Pen created at CodePen.io. You can find this one at http://codepen.io/social_quotient/pen/trbsj.

 Wanted to do something cool. Inspired by several existing systems. 

Click to edit, drag/drop, bootstrap.

Shoot me a note if you do any extensions